#!/sbin/sh

DEVICE="hammerhead"

if [ -f /tmp/boot.img-ramdisk.gz ]; then
	rm -rf /tmp/ramdisk/ && mkdir /tmp/ramdisk/

	mv /tmp/boot.img-ramdisk.gz /tmp/ramdisk/
	cd /tmp/ramdisk/

	gunzip -c /tmp/ramdisk/boot.img-ramdisk.gz | cpio -i

	rm -rf /tmp/ramdisk/boot.img-ramdisk.gz	\
	       /tmp/ramdisk/fstab.$DEVICE	\
	       /tmp/ramdisk/init.$DEVICE.rc

	if grep -q "mkdir /dev/stune" /tmp/ramdisk/init.rc; then
		cp /tmp/init.${DEVICE}_n.rc /tmp/ramdisk/init.$DEVICE.rc
	else
		cp /tmp/init.${DEVICE}.rc /tmp/ramdisk/init.$DEVICE.rc
	fi

	cp /tmp/fstab.$DEVICE /tmp/ramdisk/

	chmod 750 /tmp/ramdisk/init.$DEVICE.rc
	chmod 640 /tmp/ramdisk/fstab.$DEVICE

	find . | cpio -o -H newc | gzip > /tmp/boot.img-ramdisk.gz

	rm -rf /tmp/ramdisk/
else
	exit 1
fi

exit 0
