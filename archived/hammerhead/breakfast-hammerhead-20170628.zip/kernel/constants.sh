#!/sbin/sh

BOARD="hammerhead"
PLATFORM="msm8974"
IMGTYPE="zImage-dtb"
THERMAL_ENGINE="thermal-engine-hh"
THERMAL_CONFIG="thermal-engine-8974.conf"
