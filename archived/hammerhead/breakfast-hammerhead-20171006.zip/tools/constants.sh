#!/sbin/sh
[ -f /tmp/config.sh ] && source /tmp/config.sh || exit 1

# Break early if something was not set
[ ! $IMGTYPE ] || [ ! $BOARD ] || [ ! $PLATFORM ] ||
[ ! $THERMAL_ENGINE ] || [ ! $THERMAL_CONFIG ] ||
[ ! $TARGET_USES_MPDECISION ] && exit 1

# A directory where initramfs modification will happen.
INITRAMFS_DIR="/tmp/initramfs"

# Check the presence of a file. Returns 1 on error.
# $1 - file's name
check_presence() { [ -f $1 ] || exit 1; }
