#!/sbin/sh
[ -f /tmp/constants.sh ] && source /tmp/constants.sh || exit 1

# This command will be passed to createnewboot script to make a new boot.img
COMMAND_LINE="/tmp/mkbootimg --kernel /tmp/$IMGTYPE --ramdisk /tmp/boot.img-ramdisk.gz --cmdline \"$(cat /tmp/boot.img-cmdline)\" --board \"$(cat /tmp/boot.img-board)\" --base $(cat /tmp/boot.img-base) --pagesize $(cat /tmp/boot.img-pagesize) --kernel_offset $(cat /tmp/boot.img-kerneloff) --ramdisk_offset $(cat /tmp/boot.img-ramdiskoff) --second_offset $(cat /tmp/boot.img-secondoff) --tags_offset \"$(cat /tmp/boot.img-tagsoff)\" --hash $(cat /tmp/boot.img-hash) --output /tmp/newboot.img"

printf "#!/sbin/sh\n$COMMAND_LINE\nexit 0" > /tmp/createnewboot.sh

chmod 755 /tmp/createnewboot.sh && /tmp/createnewboot.sh

exit 0
