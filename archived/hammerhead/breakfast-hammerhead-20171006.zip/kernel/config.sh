#!/sbin/sh

# Device configuration is required to set up firmware
IMGTYPE="zImage-dtb"
BOARD="hammerhead"
PLATFORM="msm8974"
THERMAL_ENGINE="thermal-engine-hh"
THERMAL_CONFIG="thermal-engine-8974.conf"
TARGET_USES_MPDECISION=true
