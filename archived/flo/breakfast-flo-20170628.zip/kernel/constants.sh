#!/sbin/sh

BOARD="flo"
PLATFORM="msm8960"
IMGTYPE="zImage"
THERMAL_ENGINE="thermald"
THERMAL_CONFIG="thermald.conf"
