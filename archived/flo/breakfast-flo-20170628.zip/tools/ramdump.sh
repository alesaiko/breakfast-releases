#!/sbin/sh

source /tmp/constants.sh
if [ ! $BOARD ]; then exit 1; fi

if [ -f /tmp/boot.img-ramdisk.gz ]; then
	rm -rf /tmp/ramdisk/ && mkdir /tmp/ramdisk/

	mv /tmp/boot.img-ramdisk.gz /tmp/ramdisk/
	cd /tmp/ramdisk/

	gunzip -c boot.img-ramdisk.gz | cpio -i

	rm -f boot.img-ramdisk.gz \
	      fstab.$BOARD        \
	      init.$BOARD.rc

	if grep -q "mkdir /dev/stune" init.rc; then N="_n"; fi

	cp /tmp/init.${BOARD}$N.rc init.${BOARD}.rc && chmod 750 init.$BOARD.rc
	cp /tmp/fstab.$BOARD . && chmod 640 fstab.$BOARD

	find . | cpio -o -H newc | gzip > /tmp/boot.img-ramdisk.gz

	rm -rf /tmp/ramdisk/
else
	exit 1
fi

exit 0
