#!/sbin/sh

source /tmp/constants.sh
if [ ! $BOARD ] ||
   [ ! $PLATFORM ] ||
   [ ! $THERMAL_ENGINE ] ||
   [ ! $THERMAL_CONFIG ]; then exit 1; fi

find_and_restore() {
	for FILE in $(find $1* 2>/dev/null); do
		if [ ! $FILE == $1 ]; then mv -f $FILE $1; fi
	done

	if [ ! -f $1 ]; then exit 1; fi
}

# PowerHAL
find_and_restore "/system/bin/mpdecision"
find_and_restore "/system/lib/hw/power.$BOARD.so"
find_and_restore "/system/lib/hw/power.$PLATFORM.so"

# Thermal Engine
find_and_restore "/system/bin/$THERMAL_ENGINE"
find_and_restore "/system/etc/$THERMAL_CONFIG"

exit 0
