#!/sbin/sh

# Device configuration is required to set up firmware
IMGTYPE="zImage"
BOARD="flo"
PLATFORM="msm8960"
THERMAL_ENGINE="thermald"
THERMAL_CONFIG="thermald.conf"
TARGET_USES_MPDECISION=true
