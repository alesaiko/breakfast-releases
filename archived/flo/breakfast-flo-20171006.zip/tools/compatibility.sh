#!/sbin/sh
[ -f /tmp/constants.sh ] && source /tmp/constants.sh || exit 1

# PowerHAL
[ $TARGET_USES_MPDECISION == "true" ] &&
check_presence "/system/bin/mpdecision"
check_presence "/system/lib/hw/power.$BOARD.so"
check_presence "/system/lib/hw/power.$PLATFORM.so"

# Thermal Engine
check_presence "/system/bin/$THERMAL_ENGINE"
check_presence "/system/etc/$THERMAL_CONFIG"

exit 0
