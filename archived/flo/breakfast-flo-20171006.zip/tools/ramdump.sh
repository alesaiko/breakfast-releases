#!/sbin/sh
[ -f /tmp/constants.sh ] && source /tmp/constants.sh || exit 1
[ -f /tmp/boot.img-ramdisk.gz ] || exit 1

rm -rf $INITRAMFS_DIR && mkdir $INITRAMFS_DIR && cd $INITRAMFS_DIR

mv /tmp/boot.img-ramdisk.gz .
gunzip -c boot.img-ramdisk.gz | cpio -i && rm boot.img-ramdisk.gz

if [ -f /tmp/init.$BOARD.rc ]; then
	N=
	if $(grep -q "mkdir /dev/stune" init.rc); then N="_n"; fi

	rm init.$BOARD.rc
	mv /tmp/init.${BOARD}$N.rc init.$BOARD.rc && chmod 750 init.$BOARD.rc
fi

if [ -f /tmp/fstab.$BOARD ]; then
	rm fstab.$BOARD
	mv /tmp/fstab.$BOARD . && chmod 640 fstab.$BOARD
fi

find . | cpio -o -H newc | gzip > /tmp/boot.img-ramdisk.gz && cd /

rm -r $INITRAMFS_DIR

exit 0
