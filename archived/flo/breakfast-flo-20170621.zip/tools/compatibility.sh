#!/sbin/sh

BOARD="flo"
PLATFORM="msm8960"

if [ -e /system/bin/mpdecision ]; then
	mv /system/bin/mpdecision /system/bin/mpdecision-bak
fi

if [ -e /system/lib/hw/power.$BOARD.so ]; then
	mv /system/lib/hw/power.$BOARD.so /system/lib/hw/power.$BOARD.so-bak
fi

if [ -e /system/lib/hw/power.$PLATFORM.so ]; then
	mv /system/lib/hw/power.$PLATFORM.so /system/lib/hw/power.$PLATFORM.so-bak
fi

exit 0
