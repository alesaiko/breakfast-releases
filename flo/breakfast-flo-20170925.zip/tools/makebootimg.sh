#!/sbin/sh
[ -e /tmp/constants.sh ] && source /tmp/constants.sh || exit 1

# This command will be passed to createnewboot script to make a new boot.img
COMMAND_LINE="/tmp/mkbootimg --kernel /tmp/$IMGTYPE --ramdisk /tmp/boot.img-ramdisk.gz --cmdline \"$(cat /tmp/boot.img-cmdline)\" --base 0x$(cat /tmp/boot.img-base) --pagesize $(cat /tmp/boot.img-pagesize) --ramdiskaddr 0x82200000 --output /tmp/newboot.img"

printf "#!/sbin/sh\n\n$COMMAND_LINE\n\nexit 0" > /tmp/createnewboot.sh

chmod 755 /tmp/createnewboot.sh && /tmp/createnewboot.sh

exit 0
