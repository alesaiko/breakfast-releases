#!/sbin/sh
[ -f /tmp/config.sh ] && source /tmp/config.sh || exit 1

# Break early if something was not set
[ ! $IMGTYPE ] || [ ! $BOARD ] || [ ! $PLATFORM ] ||
[ ! $THERMAL_ENGINE ] || [ ! $THERMAL_CONFIG ] ||
[ ! $TARGET_USES_MPDECISION ] && exit 1

# Check the presence of a file
# $1 - file name
check_presence() { [ ! -f $1 ] && exit 1; }
