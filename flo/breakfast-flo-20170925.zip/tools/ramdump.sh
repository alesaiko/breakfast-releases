#!/sbin/sh
[ -e /tmp/constants.sh ] && source /tmp/constants.sh || exit 1

# Grab the current ramdisk and modify it on-the-fly
if [ -f /tmp/boot.img-ramdisk.gz ]; then
	mkdir /tmp/ramdisk/ && cd /tmp/ramdisk/

	mv /tmp/boot.img-ramdisk.gz .
	gunzip -c boot.img-ramdisk.gz | cpio -i

	rm -f boot.img-ramdisk.gz fstab.$BOARD init.$BOARD.rc

	N=
	if $(grep -q "mkdir /dev/stune" init.rc); then N="_n"; fi

	mv /tmp/init.${BOARD}$N.rc init.$BOARD.rc && chmod 750 init.$BOARD.rc
	mv /tmp/fstab.$BOARD . && chmod 640 fstab.$BOARD

	find . | cpio -o -H newc | gzip > /tmp/boot.img-ramdisk.gz

	rm -r /tmp/ramdisk
else
	exit 1
fi

exit 0
